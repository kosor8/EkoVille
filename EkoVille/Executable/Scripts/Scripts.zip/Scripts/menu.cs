/*
 * 
 *  ### author: arda berat kosor
 *  ### email: beratkosor43@gmail.com
 *  ### created at: 2024
 *  
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class menu : MonoBehaviour
{
    public Animator animator;
    public bool closed = true;

    // Update is called once per frame
    void Update()
    {
        if (closed)
        {
            if(Input.GetKeyDown(KeyCode.M))
            {
                closed = false;
                animator.SetBool("isOpen", true);
            }
        }
        else
        {
            if(Input.GetKeyDown(KeyCode.M))
            {
                closed = true;
                animator.SetBool("isOpen", false);
            }
        }
    }
}
