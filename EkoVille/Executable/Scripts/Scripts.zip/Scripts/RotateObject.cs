/*
 * 
 *  ### author: eren zambak 
 *  ### email: erenozlemzambak@gmail.com
 *  ### created at: 2024
 *  
*/

using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;


public class RotateObject : MonoBehaviour
{



    private RaycastHit hit;
    void Update()
    {


        if (Input.GetKeyDown(KeyCode.R))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                if (hit.collider.gameObject.tag == "Dondurabilir")
                {
                    hit.collider.gameObject.transform.Rotate(new Vector3(0, 1, 0) * -90);
                }
            }
        }
    }

}