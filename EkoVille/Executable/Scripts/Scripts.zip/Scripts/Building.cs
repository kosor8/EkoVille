/*
 * 
 *  ### author: arda berat kosor
 *  ### email: beratkosor43@gmail.com
 *  ### created at: 2024
 *  
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Building : MonoBehaviour
{
    public BuildingPreset preset;
}
