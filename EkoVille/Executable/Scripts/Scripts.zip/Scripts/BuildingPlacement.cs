/*
 * 
 *  ### author: arda berat kosor
 *  ### email: beratkosor43@gmail.com
 *  ### created at: 2024
 *  
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingPlacement : MonoBehaviour
{
    private bool currentlyPlacing;
    private bool currentlyBulldozering;


    private BuildingPreset curBuildingPreset;

    private float indicatorUpdateTime = 0.05f; // her mouse hareketinde takip etmemesi i�in/i�lemciyi rahatlatmak amac�yla
    private float lastUpdateTime;
    private Vector3 curIndicatorPos;

    public GameObject placementIndicator;
    public GameObject bulldozerIndicator;
    public GameObject placementIndicatorHouse1;
    public GameObject placementIndicatorHouse2;
    public GameObject placementIndicatorHouse3;
    public GameObject placementIndicatorHouse4;
    public GameObject placementIndicatorHouse5;
    public GameObject placementIndicatorRoad;
    public GameObject placementIndicatorRoadTurn;
    public GameObject placementIndicatorWindmill;
    public GameObject placementIndicatorFactory;


    public void BeginNewBuildingPlacement(BuildingPreset preset) // yeni building preset eklenmesi i�in 
                                                                 // asl�nda prefab de�il eklenen �ey bir preset oldu�u i�in parametresini BuildingPreset'ten al�r
                                                                 // BuildingPreset'in i�indeki fabrika, ev, tarla, yol preset'lerinden birinin se�ilmesini sa�lar
    {
        if (City.instance.money < preset.cost) // paran�n yetip yetmedi�ini kontrol eder
                                               // yetmiyorsa hi�bir �ey d�nd�rmez >>> i�lemin yap�lmas�n� engeller
        {
            return;
        }
        

        currentlyPlacing = true;
        curBuildingPreset = preset; // istenilen preset'in se�ilmesini sa�lar
        placementIndicator.SetActive(true);

        if (preset.name == "House1")
        {
            placementIndicatorHouse1.SetActive(true);
            placementIndicatorHouse2.SetActive(false);
            placementIndicatorHouse3.SetActive(false);
            placementIndicatorHouse4.SetActive(false);
            placementIndicatorHouse5.SetActive(false);
            placementIndicatorRoad.SetActive(false);
            placementIndicatorRoadTurn.SetActive(false);
            placementIndicatorFactory.SetActive(false);
            placementIndicatorWindmill.SetActive(false);
        }
        
        if (preset.name == "House2")
        {
            placementIndicatorHouse1.SetActive(false);
            placementIndicatorHouse2.SetActive(true);
            placementIndicatorHouse3.SetActive(false);
            placementIndicatorHouse4.SetActive(false);
            placementIndicatorHouse5.SetActive(false);
            placementIndicatorRoad.SetActive(false);
            placementIndicatorRoadTurn.SetActive(false);
            placementIndicatorFactory.SetActive(false);
            placementIndicatorWindmill.SetActive(false);
        }

        if (preset.name == "House3")
        {
            placementIndicatorHouse1.SetActive(false);
            placementIndicatorHouse2.SetActive(false);
            placementIndicatorHouse3.SetActive(true);
            placementIndicatorHouse4.SetActive(false);
            placementIndicatorHouse5.SetActive(false);
            placementIndicatorRoad.SetActive(false);
            placementIndicatorRoadTurn.SetActive(false);
            placementIndicatorFactory.SetActive(false);
            placementIndicatorWindmill.SetActive(false);
        }

        if (preset.name == "House4")
        {
            placementIndicatorHouse1.SetActive(false);
            placementIndicatorHouse2.SetActive(false);
            placementIndicatorHouse3.SetActive(false);
            placementIndicatorHouse4.SetActive(true);
            placementIndicatorHouse5.SetActive(false);
            placementIndicatorRoad.SetActive(false);
            placementIndicatorRoadTurn.SetActive(false);
            placementIndicatorFactory.SetActive(false);
            placementIndicatorWindmill.SetActive(false);
        }

        if (preset.name == "House5")
        {
            placementIndicatorHouse1.SetActive(false);
            placementIndicatorHouse2.SetActive(false);
            placementIndicatorHouse3.SetActive(false);
            placementIndicatorHouse4.SetActive(false);
            placementIndicatorHouse5.SetActive(true);
            placementIndicatorRoad.SetActive(false);
            placementIndicatorRoadTurn.SetActive(false);
            placementIndicatorFactory.SetActive(false);
            placementIndicatorWindmill.SetActive(false);
        }


        if (preset.name == "Road")
        {
            placementIndicatorHouse1.SetActive(false);
            placementIndicatorHouse2.SetActive(false);
            placementIndicatorHouse3.SetActive(false);
            placementIndicatorHouse4.SetActive(false);
            placementIndicatorHouse5.SetActive(false);
            placementIndicatorRoad.SetActive(true);
            placementIndicatorRoadTurn.SetActive(false);
            placementIndicatorFactory.SetActive(false);
            placementIndicatorWindmill.SetActive(false);
        }

        if (preset.name == "RoadTurn")
        {
            placementIndicatorHouse1.SetActive(false);
            placementIndicatorHouse2.SetActive(false);
            placementIndicatorHouse3.SetActive(false);
            placementIndicatorHouse4.SetActive(false);
            placementIndicatorHouse5.SetActive(false);
            placementIndicatorRoad.SetActive(false);
            placementIndicatorRoadTurn.SetActive(true);
            placementIndicatorFactory.SetActive(false);
            placementIndicatorWindmill.SetActive(false);
        }

        if (preset.name == "Factory")
        {
            placementIndicatorHouse1.SetActive(false);
            placementIndicatorHouse2.SetActive(false);
            placementIndicatorHouse3.SetActive(false);
            placementIndicatorHouse4.SetActive(false);
            placementIndicatorHouse5.SetActive(false);
            placementIndicatorRoad.SetActive(false);
            placementIndicatorRoadTurn.SetActive(false);
            placementIndicatorFactory.SetActive(true);
            placementIndicatorWindmill.SetActive(false);
        }

        if (preset.name == "Windmill")
        {
            placementIndicatorHouse1.SetActive(false);
            placementIndicatorHouse2.SetActive(false);
            placementIndicatorHouse3.SetActive(false);
            placementIndicatorHouse4.SetActive(false);
            placementIndicatorHouse5.SetActive(false);
            placementIndicatorRoad.SetActive(false);
            placementIndicatorRoadTurn.SetActive(false);
            placementIndicatorFactory.SetActive(false);
            placementIndicatorWindmill.SetActive(true);
        }
    }

    void CancelBuildingPlacement() // esc'ye bas�ld���nda i�lemi iptal ettiren fonksiyon
    {
        currentlyPlacing = false;

        placementIndicator.SetActive(false); // yerle�tirme yap�ld��� s�rada mavi k�p�n belirmesini sa�lar
    }
    void CancelBulldoze() // esc'ye bas�ld���nda i�lemi iptal ettiren fonksiyon
    {
        currentlyBulldozering = false;

        bulldozerIndicator.SetActive(false); // yerle�tirme yap�ld��� s�rada mavi k�p�n belirmesini sa�lar
    }

    public void ToggleBulldoze() // aktif preset'in kald�r�lmas�n� sa�layan fonksiyon
    {
        currentlyBulldozering = !currentlyBulldozering;
        bulldozerIndicator.SetActive(currentlyBulldozering); // bulldozering s�ras�nda k�rm�z� k�p�n belirmesini sa�lar
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.Escape))
        {
            CancelBuildingPlacement();
            CancelBulldoze();
        }

        if (Time.time - lastUpdateTime > indicatorUpdateTime)
        {
            lastUpdateTime = Time.time;

            curIndicatorPos = Selector.instance.GetCurTilePosition(); // float de�il de tam olarak k�plere oturmas�n� sa�layan fonksiyon
                                                                      // selector'daki instance sayesinde >>> mouse ile ta��nmas�n� sa�lar

            if (currentlyPlacing)
            {
                placementIndicator.transform.position = curIndicatorPos; // yerle�tirme k�sm�ndaysa placementIndicator'�n hareketini sa�lar
            }
            else if (currentlyBulldozering)
            {
                bulldozerIndicator.transform.position = curIndicatorPos; // bulldozer k�sm�ndaysa bulldozerIndicator'�n hareketini sa�lar
            }
        }

        if (Input.GetMouseButtonDown(0) && currentlyPlacing) // mouse'nin sol tu�una bas�ld�ysa ve currentlyPlacing m�saitse >>> konulmak istenen yer bo�sa
        {
            PlaceBuilding(); // yap� yerle�tirme fonksiyonunu �a��r�r
        }
        else if (Input.GetMouseButtonDown(0) && currentlyBulldozering) // mouse'nin sol tu�una bas�ld�ysa ve bulldozering durumu true ise
        {
            Bulldoze(); // yap� yok etme fonksiyonunu �a��r�r
        }

    }

    void PlaceBuilding()
    {
        GameObject buildingObj = Instantiate(curBuildingPreset.prefab, curIndicatorPos, Quaternion.identity);
        // mevcut building preset'in prefab'�n� al�p mavi k�p�n mevcut oldu�u pozisyona ta��n�p olu�turulmas�n� sa�lar

        City.instance.OnPlaceBuilding(buildingObj.GetComponent<Building>());
        // ilgili buildingObj'nin olu�turulmas�n� sa�lay�p ilgili buildingObj'nin say�sal de�erlerindeki de�i�imlerin ger�ekle�tirilmesi ve men�ye yans�t�lmas�n� sa�lar

        // CancelBuildingPlacement(); // yerle�im yap�ld�ktan sonra mavi k�p�n yok olmas�n� sa�lar
    }

    void Bulldoze()
    {
        Building buildingToDestroy = City.instance.buildings.Find(x => x.transform.position == curIndicatorPos);
        // silinecek building => position bilgisi anl�k indicator bilgisine e�it olan� bul ve atama yap

        if (buildingToDestroy != null) // gerek�elerini sa�layan buildingToDestroy varsa 
        {
            City.instance.OnRemoveBuilding(buildingToDestroy); // gerek�eleri sa�layan buildingToDestroy objesine city'nin i�indeki OnRemoveBuilding fonksiyonunu uygula
                                                               // bahsi ge�en objenin yok edilmesini sa�layan fonksiyon
        }


    }




}
