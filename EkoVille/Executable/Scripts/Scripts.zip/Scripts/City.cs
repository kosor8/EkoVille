/*
 * 
 *  ### author: arda berat kosor
 *  ### email: beratkosor43@gmail.com
 *  ### created at: 2024
 *  
*/

using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class City : MonoBehaviour
{
    public int money;
    public int day;
    public int curPopulation;
    public int curHealth = 0;

    public int incomePerPerson;
    public int factoryCounter = 0;

    public Text moneyText;
    public Text popText;
    public Text dayText;
    public Text healthText;
    public List<Building> buildings = new List<Building>();

    public Slider health;
    public int healthToWin = 1000;

    public static City instance;

    public GameObject gunes;

    [Range(0, 1)] public float time;
    public float startTime;
    public float dayLenght;   //günün süresini belirle
    private float timeRate;
    public Vector3 noon;
    public bool control = true;


    private void Awake()
    {
        instance = this;
    }

    private void Start()
    {
        UpdateStatText(); // başlangıçta değerleri güncelleyip menüye yansıtsın

        timeRate = 1 / dayLenght;
        time = startTime;
    }

    public void OnPlaceBuilding(Building building) // şehirin genel sayısal değerlerinin düzenlenmesini sağlar
    {
        money -= building.preset.cost; // seçili preset'in cost değeri kadar money değerinden düşmesini sağlar
        curPopulation += building.preset.population;
        curHealth -= building.preset.damage;
        curHealth += building.preset.health;
        health.value = curHealth;
        buildings.Add(building); // buildings değerine seçili preset'in building'ini ekler
        UpdateStatText(); // yapılan işlemlerin text kısmında güncellenmesini sağlar
    }

    public void OnRemoveBuilding(Building building)
    {
        buildings.Remove(building); // buildings değerine seçili preset'in building'ini kaldırır
        curPopulation -= building.preset.population;
        money += building.preset.remove;
        curHealth += building.preset.damage;
        curHealth -= building.preset.health;
        health.value = curHealth;
        Destroy(building.gameObject); // seçili preset'in gameObject'ini tamamen ortadan yok eder
        UpdateStatText(); // yapılan işlemlerin text kısmında güncellenmesini sağlar
    }

    void UpdateStatText()
    {
        moneyText.text = string.Format("{0}", new object[1] {money});
        dayText.text = string.Format("{0}", new object[1] { day });
        popText.text = string.Format("{0}", new object[1] { curPopulation });
        healthText.text = string.Format("{0}", new object[1] { curHealth });
        // statsText'e 7 tane yeni obje atayacak >>> day0, money1, curPopulation2... >>> indeks numaralarıyla atamalarda bulunur
    }

    public void EndTurn() // günü tamamlama fonksiyonu
    {
        CalculateMoney();
        UpdateStatText(); // her gün tamamlama fonksiyonu çağırıldığında menüdeki sayısal değerlerin gün bitiminde tekrar güncellenmesini sağlar
        day++;
    }

    void CalculateMoney()
    {
        money += (curPopulation * incomePerPerson); // her iş için iş başına düşen gelir ile iş miktarı çarpılıp genel paraya eklenir (gün sonunda)


        foreach (Building building in buildings) // buildings içindeki her bir building için 
        {
            money += building.preset.income;
        }
    }


    private void Update()
    {

        time += timeRate * Time.deltaTime;

        if (time >= 1)
        {
            time = 0;
        }

        if (time >= 0.15f && control)
        {
            EndTurn();
            control = false;
        }
        else if(time <= 0.15f)
        {
            control = true;
        }

        gunes.transform.eulerAngles = noon * ((time - 0.25f) * 4);

        if(curHealth <= 0)
        {
            SceneManager.LoadScene("basarisizEkrani");
        }

        if(curHealth >= 10000)
        {
            SceneManager.LoadScene("oyunSonuEkran");
        }


        if(money < 0)
        {
            SceneManager.LoadScene("basarisizEkrani");
        }
    }

   


}
