/*
 * 
 *  ### author: arda berat kosor
 *  ### email: beratkosor43@gmail.com
 *  ### created at: 2024
 *  
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class open : MonoBehaviour
{
    public Animator animator;
    public Animator animator2;
    public GameObject lvl;
    public GameObject road;
    public bool closed = true;
    public bool closedTree = true;

    public void OpenMenu()
    {
        if (closed)
        {
            animator.SetBool("isOpenHouse", true);
            closed = false;
            lvl.SetActive(true);

        }
        else
        {
            animator.SetBool("isOpenHouse", false);
            closed = true;
            lvl.SetActive(false);
        }
    }

    public void OpenRoadMenu()
    {
        if(closedTree)
        {
            animator2.SetBool("isOpenRoad", true);
            closedTree = false;
            road.SetActive(true);
        }
        else
        {
            animator2.SetBool("isOpenRoad", false);
            closedTree = true;
            road.SetActive(false);
        }
    }
}
