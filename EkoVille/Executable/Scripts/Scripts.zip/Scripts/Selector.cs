/*
 * 
 *  ### author: eren zambak 
 *  ### email: erenozlemzambak@gmail.com
 *  ### created at: 2024
 *  
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Selector : MonoBehaviour
{
    private Camera cam;
    public static Selector instance; // ba�ka bir scriptten de fonksiyonlara ula��lmas�n� sa�lar

    private void Awake()
    {
        instance = this; // selector script'indeki herhangi bir fonksiyona ba�ka bir scriptten do�rudan eri�ilmesini sa�lar
    }

    private void Start()
    {
        cam = Camera.main;
    }

    public Vector3 GetCurTilePosition()
    {
        if (EventSystem.current.IsPointerOverGameObject()) // ui'ya de�diyse anlam�na gelir >>> canvas'a eri�tiyse/dokunduysa
        {
            return new Vector3(0, -99, 0);
        }

        Plane plane = new Plane(Vector3.up, Vector3.zero); // hayali bir zemin olu�turur ve �l��leri de yandaki de�erler gibidir

        Ray ray = cam.ScreenPointToRay(Input.mousePosition);

        float rayOut = 0;

        // yukaridaki kodlar�n amac� zemine herhangi bir temas durumunda zemini tespit edilmesi !!!

        if (plane.Raycast(ray, out rayOut)) // zemine(ground) dokunduysa anlam�na gelir >>> ray temas ettiyse
        {
            Vector3 newPos = ray.GetPoint(rayOut) - new Vector3(0.05f, 0.0f, 0.05f); // ground'da dokunulan yerin pozisyon bilgisini ald�k

            newPos = new Vector3(Mathf.CeilToInt(newPos.x), 0, Mathf.CeilToInt(newPos.z)); // �ste tamamlama fonksiyonu
                                                                                           // float de�erleri tam de�erlere/int yuvarlanmas�n�(�ste do�ru) sa�lar

            return newPos; // ve dokunulan yerin pozisyonuna gidilmesini sa�lad�k
        }
        // if k�sm� nesnenin tam t�klan�ld��� yere float olarak de�il de int/tam say� olarak yerle�tirilmesini sa�lar

        return new Vector3(0, -99, 0); // alakas�z
    }

}
