/*
 * 
 *  ### author: eren zambak 
 *  ### email: erenozlemzambak@gmail.com
 *  ### created at: 2024
 *  
*/

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CamController : MonoBehaviour
{
    public float moveSpeed;

    public float minXRot;
    public float maxXRot;

    private float curXRot;

    public float minZoom;
    public float maxZoom;

    public float rotateSpeed;
    public float zoomSpeed;

    private float curZoom;

    private Camera cam;

    private void Start()
    {
        cam = Camera.main; // main kameraya atar
        curZoom = cam.transform.localPosition.y; // zoom i�lemleri y ekseniyle yap�ld��� i�in .y kullan�l�r
        curXRot = -50;
    }

    private void Update()
    {
        curZoom += Input.GetAxis("Mouse ScrollWheel") * -zoomSpeed; // mouse tekerli�ini d�nd�rd�k�e yak�nla�t�rma uzakla�t�rma yap�lmas�n� sa�lar
        curZoom = Mathf.Clamp(curZoom, minZoom, maxZoom); // curZoom de�erini min ve max zoom de�erleri aras�nda tutulmas�n� sa�lar
                                                          // e�er min'den k���kse min'e
                                                          // max'tan b�y�kse max'a e�itler

        cam.transform.localPosition = Vector3.up * curZoom; // up olmas�n� sebebi zoom i�lemini yukar� veya a�a�� do�ru yap�lmas� >>> y ekseninde

        if (Input.GetMouseButton(1)) // sa� tu�a bas�l�yken etrafa bak�lmas�n� sa�lar
        {
            float x = Input.GetAxis("Mouse X");
            float y = Input.GetAxis("Mouse Y");

            curXRot -= y * rotateSpeed;
            curXRot = Mathf.Clamp(curXRot, minXRot, maxXRot);
            transform.eulerAngles = new Vector3(curXRot, transform.eulerAngles.y + (x * rotateSpeed), 0); // mouse'un x ekseninde hareketi sonucu a�� y ekseni etraf�nda de�i�ir
                                                                                                          // y ekseninde hareketi sonucu da a�� x etraf�nda de�i�ir
                                                                                                          // bu y�zden vekt�r�n x k�sm�na curXRot yani asl�nda y*rotateSpeed yaz�l�r
                                                                                                          // ve y k�sm�na da kendi y'si + x*rotateSpeed yaz�l�r

            // !!! mouse'nin x eksenindeki hareketi sonucunda d�nme olay� y ekseni etraf�nda ger�ekle�irken
            //               y eksenindeki hareketi sonucunda ise d�nme olay� x ekseni etraf�nda ger�ekle�ir
        }


        // HAREKET

        Vector3 forward = cam.transform.forward;
        forward.y = 0;
        forward.Normalize();

        Vector3 right = cam.transform.right;

        float moveX = Input.GetAxisRaw("Horizontal");
        float moveZ = Input.GetAxisRaw("Vertical");

        Vector3 dir = forward * moveZ + right * moveX;
        // forward >>> z ekseni 
        // right >>> x ekseni
        dir.Normalize();

        dir *= moveSpeed * Time.deltaTime;

        transform.position += dir;
    }



}
